using System.Diagnostics;

namespace Launcher {
    /* Drag and Drop a single File into listbox.
     * And Launch it when a button is clicked
     */ 
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            textBox1.AllowDrop = true;
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                e.Effect = DragDropEffects.Copy;
            } else {
                e.Effect = DragDropEffects.None;
            }
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;
            string fn;

            filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
            fn = filenames.GetValue(0).ToString();
            textBox1.Text = fn;
        }

        private void launchBtn_Click(object sender, EventArgs e) {
            string fn;
            System.Diagnostics.Process p;

            fn = textBox1.Text;
            if (System.IO.File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }
    }
}