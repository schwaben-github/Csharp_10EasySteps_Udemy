using Microsoft.VisualBasic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Xml;

namespace Launcher {
    // 8 - Use Standard Panel
    
    public partial class Form1 : Form {

        string recfile;

        bool dragging;
        int xoffset;
        int yoffset;

        public Form1() {
            InitializeComponent();
            recfile = Path.GetDirectoryName(Application.ExecutablePath) + "\\recfile.sav";
            // Add ItemClicked event-handler for context menu
            popupMenu.ItemClicked += new ToolStripItemClickedEventHandler(popupMenu_ItemClicked);
            dragging = false;
        }

        private void MouseDown(object sender, MouseEventArgs e) {
            Button b;

            b = (Button)sender;

            if (Control.ModifierKeys == Keys.Control) {
                dragging = true;
                xoffset = e.X;
                yoffset = e.Y;
            }
        }

        private void MouseUp(object sender, MouseEventArgs e) {
            dragging = false;
        }

        private void MouseMove(object sender, MouseEventArgs e) {
            Button b;
            int XMoved;
            int YMoved;
            int newBtnX;
            int newBtnY;

            b = (Button)sender;
            if (dragging) {
                // calculate mouse pointer movement                
                XMoved = e.Location.X - xoffset;
                YMoved = e.Location.Y - yoffset;

                // Calculate new pos of button as its current pos plus
                // number of pixels that the mouse was moved so that the
                // pointer offset is retained relative to the button.
                newBtnX = b.Location.X + XMoved;
                newBtnY = b.Location.Y + YMoved;

                // Don't move the button in X or Y directions if that will
                // move it outside the client area of the form
                // X
                if (newBtnX <= 0) {
                    newBtnX = b.Location.X;
                } else if (newBtnX + b.Width >= this.ClientSize.Width) {
                    newBtnX = b.Location.X;
                }
                // Y
                if (newBtnY <= 0) {
                    newBtnY = b.Location.Y;
                } else if (newBtnY + b.Height >= this.ClientSize.Height) {
                    newBtnY = b.Location.Y;
                }

                // Move Button
                b.Location = new Point(newBtnX, newBtnY);
            }
        }
        private Icon GetExplorerIcon() {
            string winfolder;
            Icon icn;

            winfolder = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            icn = Icon.ExtractAssociatedIcon(winfolder + "\\explorer.exe");
            return icn;
        }

        private Button CreateButton(string path, Icon icn) {
            Button btn;

            btn = new System.Windows.Forms.Button();
            btn.Size = new System.Drawing.Size(80, 80);
            btn.UseVisualStyleBackColor = true;
            btn.Text = Path.GetFileName(path);
            btn.Tag = path;
            // add event-handlers
            btn.Click += new EventHandler(btn_Click);
            btn.MouseDown += new MouseEventHandler(MouseDown);
            btn.MouseMove += new MouseEventHandler(MouseMove);
            btn.MouseUp += new MouseEventHandler(MouseUp);
            // set alignment
            btn.TextAlign = ContentAlignment.BottomCenter;
            btn.ImageAlign = ContentAlignment.TopCenter;
            // add icon image            
            btn.Image = icn.ToBitmap();
            // Add Context Menu
            btn.ContextMenuStrip = popupMenu;
            return btn;
        }

        private void SetBtnPos(Button b) {
            int numctrls = mainpanel.Controls.Count;
            if (numctrls > 0) {
                Button lastBtn = (Button)mainpanel.Controls[numctrls - 1];
                int lastX = lastBtn.Location.X;
                b.Location = new Point(lastX + lastBtn.Width + 10, lastBtn.Location.Y);
            } else {
                b.Location = new Point(10, 10);
            }
            // return b;
        }
        private void AddButton(string path) {
            Button btn;
            Icon icn;

            if (File.Exists(path)) {
                icn = System.Drawing.Icon.ExtractAssociatedIcon(path);
                btn = CreateButton(path, icn);
                SetBtnPos(btn);
                mainpanel.Controls.Add(btn);
            } else if (Directory.Exists(path)) {
                icn = GetExplorerIcon();
                btn = CreateButton(path, icn);
                mainpanel.Controls.Add(btn);
            }
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else if (Directory.Exists(fn)) {
                Process.Start("explorer.exe", fn);
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }

        private void SaveConfig(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                foreach (Control c in mainpanel.Controls) {
                    outputFile.WriteLine(c.Tag);
                }
            }
        }

        private void LoadConfig(string path) {
            List<string> lines = new List<string>();

            mainpanel.Controls.Clear();

            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddButton(s);
            }
        }

        private void btn_Click(object sender, EventArgs e) {
            if (!dragging) {
                LaunchFile(((Button)sender).Tag.ToString());
            }
        }


        private void DeleteBtn(Button btn) {
            if (mainpanel.Controls.Contains(btn)) {
                if (MessageBox.Show("Delete " + btn.Text, "Remove Button", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    mainpanel.Controls.Remove(btn);
                }
            }
        }

        private void ReOrderButtons() {
            string[] paths = new string[mainpanel.Controls.Count];
            Button b;
            string s = "";

            
            for (int i = 0; i < mainpanel.Controls.Count; i++) {
                b = (Button)mainpanel.Controls[i];
                paths[i] = (string)b.Tag;
            }

            mainpanel.Controls.Clear();
          this.SuspendLayout();
            for (int i = 0; i < paths.Length; i++) {
                AddButton(paths[i]);
            }
          this.ResumeLayout();
        }

        private void MoveLeft(Button btn) {
            int index;

            index = mainpanel.Controls.GetChildIndex(btn);
            if (index > 0) {
                mainpanel.Controls.SetChildIndex(btn, index - 1);
            }
            ReOrderButtons();
        }

        private void MoveRight(Button btn) {
            int index;

            index = mainpanel.Controls.GetChildIndex(btn);
            if (index <= mainpanel.Controls.Count) {
                mainpanel.Controls.SetChildIndex(btn, index + 1);
            }
            ReOrderButtons();
        }
        private void popupMenu_ItemClicked(Object sender, ToolStripItemClickedEventArgs e) {
            string menuitem;
            string btn_name;
            Button btn;

            btn = (Button)popupMenu.SourceControl;
            btn_name = btn.Text;
            menuitem = (e.ClickedItem).ToString();

            if (e.ClickedItem == delBtnMenuItem) {
                DeleteBtn(btn);
            } else if (e.ClickedItem == moveLeftMenuItem) {
                MoveLeft((Button)popupMenu.SourceControl);
            } else if (e.ClickedItem == moveRightMenuItem) {
                MoveRight((Button)popupMenu.SourceControl);
            } else {
                MessageBox.Show("Unknown Menu Item: menuitem=" + menuitem);
            }
        }

        private void flowLayoutPanel1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {
                    AddButton(s);
                }
            }
        }

        private void flowLayoutPanel1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e) {
            mainpanel.Controls.Clear();
        }

        private void OpenThisFile(object ob, System.EventArgs e) {
            // RecFileMenu Click Handler
            string fn = "";
            FileInfo fi;

            fn = ((ToolStripMenuItem)ob).Text;
            fi = new FileInfo(fn);
            if (fi.Exists) {
                LoadConfig(fn);
            }
        }
        private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
            openFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                mainpanel.Controls.Clear();
                LoadConfig(openFileDialog1.FileName);
                AddToRecFileMenu(openFileDialog1.FileName);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveConfig(saveFileDialog1.FileName);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }
        private void AddToRecFileMenu(string fn) {
            // limit of 4 Files in menu
            if (fn != null) { // don't add a blank entry
                if (recFileMenu.DropDownItems.Count > 3) {
                    recFileMenu.DropDownItems.RemoveAt(recFileMenu.DropDownItems.Count - 1);
                }
                recFileMenu.DropDownItems.Add(new ToolStripMenuItem(fn, null, new EventHandler(OpenThisFile)));
            }
        }

        private void LoadRecFiles(string path) {
            List<string> lines = new List<string>();


            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddToRecFileMenu(s);
            }
        }
        private void Form1_Load(object sender, EventArgs e) {
            string path;

            if (File.Exists(recfile)) {
                LoadRecFiles(recfile);
            }
            // Load Buttons
            path = Path.GetDirectoryName(Application.ExecutablePath) + $"\\config.txt";
            if (File.Exists(path)) {
                this.Text = path;
                LoadConfig(path);
            }

        }

        private void SaveRecFiles(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                for (int i = 0; i < recFileMenu.DropDownItems.Count; i++) {
                    outputFile.WriteLine(recFileMenu.DropDownItems[i].Text);
                }
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            // Save Recently opened File names           
            SaveRecFiles(recfile);
        }

        private void ctrlInfoToolStripMenuItem_Click(object sender, EventArgs e) {
            string s = "";
            Control c;
            for (int i = 0; i < mainpanel.Controls.Count; i++) {
                c = mainpanel.Controls[i];
                s += $"[{i}] index={mainpanel.Controls.GetChildIndex(c)} {c.Text}\r\n";
            }
            MessageBox.Show(s);

        }
    }

}