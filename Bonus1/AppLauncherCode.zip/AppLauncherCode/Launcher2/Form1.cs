using System.Diagnostics;

namespace Launcher {
    public partial class Form1 : Form {
        /* Drag & Drop multiple files into listbox and
         * double-click to launch a selected file 
         */
        public Form1() {
            InitializeComponent();
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (System.IO.File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }

        private void listView1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {
                    listView1.Items.Add(s);
                }
            }
        }

        private void listView1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void listView1_DoubleClick(object sender, EventArgs e) {
            string fn;

            fn = listView1.FocusedItem.Text;
            LaunchFile(fn);
        }
    }
}