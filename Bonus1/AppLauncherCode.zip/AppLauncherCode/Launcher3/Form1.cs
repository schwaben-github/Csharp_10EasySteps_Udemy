using System.Diagnostics;

namespace Launcher {
    public partial class Form1 : Form {
        /* Create buttons in a flowpanel - with labels and
         * icons. Set AllowDrop to true in flowPanel and
         * add dragenter and dragdrop event-handletrs.
         * Launch file when button is clicked 
         */

        public Form1() {
            InitializeComponent();
        }
        
        private void AddButton(string path) {
            Button btn;
            Icon iconForFile;

            btn = new System.Windows.Forms.Button();                     
            btn.Size = new System.Drawing.Size(80, 80);
            btn.UseVisualStyleBackColor = true;
            btn.Text = Path.GetFileName(path);
            btn.Tag = path;           
            // set alignment
            btn.TextAlign = ContentAlignment.BottomCenter;
            btn.ImageAlign = ContentAlignment.TopCenter;
            // add icon image
            iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(path);
            btn.Image = iconForFile.ToBitmap();
            btn.Click += new EventHandler(btn_Click);
            flowLayoutPanel1.Controls.Add(btn);
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (System.IO.File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }       

        private void btn_Click(object sender, EventArgs e) {
            LaunchFile(((Button)sender).Tag.ToString());
        }

        private void flowLayoutPanel1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {                   
                    AddButton(s);
                }
            }
        }

        private void flowLayoutPanel1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }
    }
}