using Microsoft.VisualBasic;
using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Xml;

namespace Launcher {
    public partial class Form1 : Form {
        // 9 Use FlowPanel with Drag/Drop        

        string defaultConfigFile = "config.txt";
        string recfile;

        bool dragging;
        int xoffset;
        int yoffset;

        public Form1() {
            InitializeComponent();
            recfile = Path.GetDirectoryName(Application.ExecutablePath) + "\\recfile.sav";
            // ** Add ItemClicked event-handler for context menu
            popupMenu.ItemClicked += new ToolStripItemClickedEventHandler(popupMenu_ItemClicked);
            dragging = false;
        }

        private void MouseDown(object sender, MouseEventArgs e) {
            Button b;

            b = (Button)sender;

            if ((e.Button == MouseButtons.Left) & (Control.ModifierKeys == Keys.Control)) {
                flowLayoutPanel1.SuspendLayout();
                flowLayoutPanel1.Controls.SetChildIndex(b, 0);
                dragging = true;
                xoffset = e.X;
                yoffset = e.Y;
            }
        }

        private int GetIndexOfOverlappedButton(Button b) {
            // Try to find if dragged button overlaps another
            // button. If so, return the index of overlapped button
            Point bloc;
            int idx;

            bloc = b.Location;
            idx = -1;
            foreach (Button b1 in flowLayoutPanel1.Controls) {
                if ((b.Location.X > b1.Location.X) & (b.Location.X < (b1.Location.X + b.Width) &
                    (b.Location.Y > b1.Location.Y) & (b.Location.Y < (b1.Location.Y + b.Height)
                    ))) {
                    idx = flowLayoutPanel1.Controls.GetChildIndex(b1);
                }
            }
            return idx;
        }
        private void MouseUp(object sender, MouseEventArgs e) {
            Button b;
            int idx;

            b = (Button)sender;

            if (dragging) {
                dragging = false;
                idx = GetIndexOfOverlappedButton(b);
                if (idx != -1) {
                    flowLayoutPanel1.Controls.SetChildIndex(b, idx);
                }
                flowLayoutPanel1.ResumeLayout();
            }
        }

        private void MouseMove(object sender, MouseEventArgs e) {
            Button b;
            int XMoved;
            int YMoved;
            int newBtnX;
            int newBtnY;

            b = (Button)sender;
            if (dragging) {
                // calculate mouse pointer movement                
                XMoved = e.Location.X - xoffset;
                YMoved = e.Location.Y - yoffset;

                // Calculate new pos of button as its current pos plus
                // number of pixels that the mouse was moved so that the
                // pointer offset is retained relative to the button.
                newBtnX = b.Location.X + XMoved;
                newBtnY = b.Location.Y + YMoved;

                // Don't move the button in X or Y directions if that will
                // move it outside the client area of the form
                // X
                if (newBtnX <= 0) {
                    newBtnX = b.Location.X;
                } else if (newBtnX + b.Width >= this.ClientSize.Width) {
                    newBtnX = b.Location.X;
                }
                // Y
                if (newBtnY <= 0) {
                    newBtnY = b.Location.Y;
                } else if (newBtnY + b.Height >= this.ClientSize.Height) {
                    newBtnY = b.Location.Y;
                }

                // Move Button
                b.Location = new Point(newBtnX, newBtnY);
            }
        }

        private Icon GetExplorerIcon() {
            string winfolder;
            Icon icn;

            winfolder = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            icn = Icon.ExtractAssociatedIcon(winfolder + "\\explorer.exe");
            return icn;
        }
        private Button CreateButton(string path, Icon icn) {
            Button btn;

            btn = new System.Windows.Forms.Button();
            btn.Size = new System.Drawing.Size(80, 80);
            btn.UseVisualStyleBackColor = true;
            btn.Text = Path.GetFileName(path);
            btn.Tag = path;
            // add event-handlers
            btn.Click += new EventHandler(btn_Click);
            btn.MouseDown += new MouseEventHandler(MouseDown);
            btn.MouseMove += new MouseEventHandler(MouseMove);
            btn.MouseUp += new MouseEventHandler(MouseUp);
            // set alignment
            btn.TextAlign = ContentAlignment.BottomCenter;
            btn.ImageAlign = ContentAlignment.TopCenter;
            // add icon image            
            btn.Image = icn.ToBitmap();
            // Add Context Menu
            btn.ContextMenuStrip = popupMenu;
            return btn;
        }

        private void SetBtnPos(Button b) {
            // Redundant???
            int numctrls = flowLayoutPanel1.Controls.Count;
            if (numctrls > 0) {
                Button lastBtn = (Button)flowLayoutPanel1.Controls[numctrls - 1];
                int lastX = lastBtn.Location.X;
                b.Location = new Point(lastX + lastBtn.Width + 10, lastBtn.Location.Y);
            } else {
                b.Location = new Point(10, 10);
            }
            // return b;
        }
        private void AddButton(string path) {
            Button btn;
            Icon icn;

            if (File.Exists(path)) {
                icn = System.Drawing.Icon.ExtractAssociatedIcon(path);
                btn = CreateButton(path, icn);
                //    SetBtnPos(btn);
                flowLayoutPanel1.Controls.Add(btn);
            } else if (Directory.Exists(path)) {
                icn = GetExplorerIcon();
                btn = CreateButton(path, icn);
                flowLayoutPanel1.Controls.Add(btn);
            }
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else if (Directory.Exists(fn)) {
                Process.Start("explorer.exe", fn);
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }

        private void SaveConfig(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                foreach (Control c in flowLayoutPanel1.Controls) {
                    outputFile.WriteLine(c.Tag);
                }
            }
        }

        private void LoadConfig(string path) {
            List<string> lines = new List<string>();

            flowLayoutPanel1.Controls.Clear();
            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddButton(s);
            }
        }

        private void btn_Click(object sender, EventArgs e) {
            if (!dragging) {
                LaunchFile(((Button)sender).Tag.ToString());
            }
        }

        private void DeleteBtn(Button btn) {
            // ** MouseMenu Delete: Confirm and remove selected button
            if (flowLayoutPanel1.Controls.Contains(btn)) {
                if (MessageBox.Show("Delete " + btn.Text, "Remove Button", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    flowLayoutPanel1.Controls.Remove(btn);
                }
            }
        }

        private void MoveLeft(Button btn) {
            // ** MouseMenu MoveLeft
            int index;

            index = flowLayoutPanel1.Controls.GetChildIndex(btn);
            if (index > 0) {
                flowLayoutPanel1.Controls.SetChildIndex(btn, index - 1);
            }
        }

        private void MoveRight(Button btn) {
            // ** MouseMenu MoveRight
            int index;

            index = flowLayoutPanel1.Controls.GetChildIndex(btn);
            if (index <= flowLayoutPanel1.Controls.Count) {
                flowLayoutPanel1.Controls.SetChildIndex(btn, index + 1);
            }
        }
        private void popupMenu_ItemClicked(Object sender, ToolStripItemClickedEventArgs e) {
            // * Handle Mouse Menu Item clicked
            string menuitem;
            Button btn;

            btn = (Button)popupMenu.SourceControl;
            menuitem = (e.ClickedItem).Text;

            if (e.ClickedItem == delBtnMenuItem) {
                DeleteBtn(btn);
            } else if (e.ClickedItem == moveLeftMenuItem) {
                MoveLeft(btn);
            } else if (e.ClickedItem == moveRightMenuItem) {
                MoveRight(btn);
            } else {
                MessageBox.Show("Unknown Menu Item: menuitem=" + menuitem);
            }
        }

        private void flowLayoutPanel1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {
                    AddButton(s);
                }
            }
        }

        private void flowLayoutPanel1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e) {
            flowLayoutPanel1.Controls.Clear();
        }

        private void OpenThisFile(object ob, System.EventArgs e) {
            // RecFileMenu Click Handler
            string fn = "";
            FileInfo fi;

            fn = ((ToolStripMenuItem)ob).Text;
            fi = new FileInfo(fn);
            if (fi.Exists) {
                LoadConfig(fn);
            }
        }
        private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
            openFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                flowLayoutPanel1.Controls.Clear();
                LoadConfig(openFileDialog1.FileName);
                AddToRecFileMenu(openFileDialog1.FileName);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveConfig(saveFileDialog1.FileName);
            }
        }

        private void saveAstoolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveConfig(saveFileDialog1.FileName);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }
        private void AddToRecFileMenu(string fn) {
            // limit of 4 Files in menu
            if (fn != null) { // don't add a blank entry
                if (recFileMenu.DropDownItems.Count > 3) {
                    recFileMenu.DropDownItems.RemoveAt(recFileMenu.DropDownItems.Count - 1);
                }
                recFileMenu.DropDownItems.Add(new ToolStripMenuItem(fn, null, new EventHandler(OpenThisFile)));
            }
        }



        private void LoadRecFiles(string path) {
            List<string> lines = new List<string>();


            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddToRecFileMenu(s);
            }
        }
        private void Form1_Load(object sender, EventArgs e) {
            string path;

            if (File.Exists(recfile)) {
                LoadRecFiles(recfile);
            }
            // Load Buttons
            path = Path.GetDirectoryName(Application.ExecutablePath) + $"\\config.txt";
            if (File.Exists(path)) {
                this.Text = path;
                LoadConfig(path);
            }

        }

        private void SaveRecFiles(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                for (int i = 0; i < recFileMenu.DropDownItems.Count; i++) {
                    outputFile.WriteLine(recFileMenu.DropDownItems[i].Text);
                }
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            // Save Recently opened File names           
            SaveRecFiles(recfile);
        }


    }

}