using System.Collections.Specialized;
using System.Configuration;
using System.Xml;

namespace ConfigTest {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();           
        }

        void ReadSettings() {
            try {
                NameValueCollection appSettings = ConfigurationManager.AppSettings;
                string x = appSettings["x"] ?? "";
                string y = appSettings["y"] ?? "";
                string width = appSettings["width"] ?? "";
                string height = appSettings["height"] ?? "";
                if ((x != "") && (y != "")) {
                    this.Location = new Point(Int32.Parse(x), Int32.Parse(y));
                }
                if (width != "") {
                    this.Width = Int32.Parse(width);
                }
                if (height != "") {
                    this.Height = Int32.Parse(height);
                }
            } catch (ConfigurationErrorsException) {
                Console.WriteLine("Error reading settings");
            }
        }
        void WriteSettings(string key, string value) {
            try {
                Configuration configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                KeyValueConfigurationCollection settings = configFile.AppSettings.Settings;
                if (settings[key] == null) {
                    settings.Add(key, value);
                } else {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            } catch (ConfigurationErrorsException) {                
                Console.WriteLine("Error writing settings");
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            WriteSettings("x", this.Location.X.ToString());
            WriteSettings("y", this.Location.Y.ToString());
            WriteSettings("width", this.Width.ToString());
            WriteSettings("height", this.Height.ToString());
        }

        private void Form1_Load(object sender, EventArgs e) {
            ReadSettings();
        }
    }
}