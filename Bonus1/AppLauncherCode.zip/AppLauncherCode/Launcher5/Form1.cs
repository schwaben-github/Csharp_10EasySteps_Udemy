using System.IO;

namespace Launcher {
    public partial class Form1 : Form {
        /* Save and Load named Config files
         */

        string defaultConfigFile = "config.txt";

        public Form1() {
            InitializeComponent();
        }

        private void AddButton(string path) {
            Button btn;
            Icon iconForFile;

            if (System.IO.File.Exists(path)) {
                btn = new System.Windows.Forms.Button();
                btn.Size = new System.Drawing.Size(80, 80);
                btn.UseVisualStyleBackColor = true;
                btn.Text = Path.GetFileName(path);
                btn.Tag = path;
                btn.Click += new EventHandler(btn_Click);
                // set alignment
                btn.TextAlign = ContentAlignment.BottomCenter;
                btn.ImageAlign = ContentAlignment.TopCenter;
                // add icon image
                iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(path);
                btn.Image = iconForFile.ToBitmap();
                flowLayoutPanel1.Controls.Add(btn);
            } else {
                // display error message?
            }
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (System.IO.File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }

        private void SaveConfig(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                foreach (Control c in flowLayoutPanel1.Controls) {
                    outputFile.WriteLine(c.Tag);
                }
            }
        }

        private void LoadConfig(string path) {
            List<string> lines = new List<string>();

            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddButton(s);
            }
        }

        private void btn_Click(object sender, EventArgs e) {
            LaunchFile(((Button)sender).Tag.ToString());
        }

        private void flowLayoutPanel1_DragDrop(object sender, DragEventArgs e) {
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {
                    AddButton(s);
                }
            }
        }

        private void flowLayoutPanel1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e) {
            flowLayoutPanel1.Controls.Clear();
        }

        private void Form1_Load(object sender, EventArgs e) {
            string path;

            path = Path.GetDirectoryName(Application.ExecutablePath) + $"\\config.txt";
            if (File.Exists(path)) {
                this.Text = Path.GetFileName(path);
                LoadConfig(path);
            }
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
            openFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                flowLayoutPanel1.Controls.Clear();
                LoadConfig(openFileDialog1.FileName);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveConfig(saveFileDialog1.FileName);
            }
        }
    }

}