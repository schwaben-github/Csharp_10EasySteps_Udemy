using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;

namespace Launcher {
    public partial class Form1 : Form {
        // 10 - Add Config file to save application configuration

        string defaultProgGroupFile = ""; // last loaded prog group file
        string recfile;

        bool dragging;
        int xoffset;
        int yoffset;

        public Form1() {
            InitializeComponent();
            recfile = Path.GetDirectoryName(Application.ExecutablePath) + "\\recfile.sav";
            // ** Add ItemClicked event-handler for context menu
            popupMenu.ItemClicked += new ToolStripItemClickedEventHandler(popupMenu_ItemClicked);
            dragging = false;
        }

        private int GetIndexOfOverlappedButton(Button b) {
            // Try to find if dragged button overlaps another
            // button. If so, return the index of overlapped button
            Point bloc;
            int idx;

            bloc = b.Location;
            idx = -1;
            foreach (Button b1 in flowLayoutPanel1.Controls) {
                if ((b.Location.X > b1.Location.X) & (b.Location.X < (b1.Location.X + b.Width) &
                    (b.Location.Y > b1.Location.Y) & (b.Location.Y < (b1.Location.Y + b.Height)
                    ))) {
                    idx = flowLayoutPanel1.Controls.GetChildIndex(b1);
                }
            }
            return idx;
        }
        private void MouseDown(object sender, MouseEventArgs e) {
            // CTRL+MouseDown starts a button dragging operation
            Button b;

            b = (Button)sender;

            if ((e.Button == MouseButtons.Left) & (Control.ModifierKeys == Keys.Control)) {
                flowLayoutPanel1.SuspendLayout();
                flowLayoutPanel1.Controls.SetChildIndex(b, 0);
                dragging = true;
                xoffset = e.X;
                yoffset = e.Y;
            }
        }

        private void MouseUp(object sender, MouseEventArgs e) {
            // If button in dragging mode, turn off dragging, position dragged button
            Button b;
            int idx;

            b = (Button)sender;

            if (dragging) {
                dragging = false;
                idx = GetIndexOfOverlappedButton(b);
                // Position dragged button to right of an overlapped button
                if (idx != -1) {
                    flowLayoutPanel1.Controls.SetChildIndex(b, idx);
                }
                flowLayoutPanel1.ResumeLayout();
            }
        }

        private void MouseMove(object sender, MouseEventArgs e) {
            // drag button if in dragging mode
            Button b;
            int XMoved;
            int YMoved;
            int newBtnX;
            int newBtnY;

            b = (Button)sender;
            if (dragging) {
                // calculate mouse pointer movement                
                XMoved = e.Location.X - xoffset;
                YMoved = e.Location.Y - yoffset;

                // Calculate new pos of button as its current pos plus
                // number of pixels that the mouse was moved so that the
                // pointer offset is retained relative to the button.
                newBtnX = b.Location.X + XMoved;
                newBtnY = b.Location.Y + YMoved;

                // Don't move the button in X or Y directions if that will
                // move it outside the client area of the form
                // X
                if (newBtnX <= 0) {
                    newBtnX = b.Location.X;
                } else if (newBtnX + b.Width >= this.ClientSize.Width) {
                    newBtnX = b.Location.X;
                }
                // Y
                if (newBtnY <= 0) {
                    newBtnY = b.Location.Y;
                } else if (newBtnY + b.Height >= this.ClientSize.Height) {
                    newBtnY = b.Location.Y;
                }

                // Move Button
                b.Location = new Point(newBtnX, newBtnY);
            }
        }

        private Icon GetExplorerIcon() {
            string winfolder;
            Icon icn;

            winfolder = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            icn = Icon.ExtractAssociatedIcon(winfolder + "\\explorer.exe");
            return icn;
        }

        private Button CreateButton(string path, Icon icn) {
            Button btn;

            btn = new System.Windows.Forms.Button();
            btn.Size = new System.Drawing.Size(80, 80);
            btn.UseVisualStyleBackColor = true;
            btn.Text = Path.GetFileName(path);
            btn.Tag = path;
            // add event-handlers
            btn.Click += new EventHandler(OnClick_LaunchButton);
            btn.MouseDown += new MouseEventHandler(MouseDown);
            btn.MouseMove += new MouseEventHandler(MouseMove);
            btn.MouseUp += new MouseEventHandler(MouseUp);
            // set alignment
            btn.TextAlign = ContentAlignment.BottomCenter;
            btn.ImageAlign = ContentAlignment.TopCenter;
            // add icon image            
            btn.Image = icn.ToBitmap();
            // Add Context Menu
            btn.ContextMenuStrip = popupMenu;
            return btn;
        }

        private void AddButton(string path) {
            Button btn;
            Icon icn;

            if (File.Exists(path)) {
                icn = System.Drawing.Icon.ExtractAssociatedIcon(path);
                btn = CreateButton(path, icn);
                flowLayoutPanel1.Controls.Add(btn);
            } else if (Directory.Exists(path)) {
                icn = GetExplorerIcon();
                btn = CreateButton(path, icn);
                flowLayoutPanel1.Controls.Add(btn);
            }
        }

        private void LaunchFile(string fn) {
            System.Diagnostics.Process p;

            if (File.Exists(fn)) {
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = fn;
                p.StartInfo.UseShellExecute = true;
                p.Start();
            } else if (Directory.Exists(fn)) {
                Process.Start("explorer.exe", fn);
            } else {
                MessageBox.Show(fn + " doesn't Exist!");
            }
        }


        /* App Config. Read and write ssettings that can be restored when the
         * application is next run
         * */

        void ReadSettings() {
            try {
                NameValueCollection appSettings = ConfigurationManager.AppSettings;
                string x = appSettings["x"] ?? "";
                string y = appSettings["y"] ?? "";
                string width = appSettings["width"] ?? "";
                string height = appSettings["height"] ?? "";
                string defaultpgfile = appSettings["defaultpgfile"] ?? "";

                if ((x != "") && (y != "")) {
                    this.Location = new Point(Int32.Parse(x), Int32.Parse(y));
                }
                if (width != "") {
                    this.Width = Int32.Parse(width);
                }
                if (height != "") {
                    this.Height = Int32.Parse(height);
                }
                if (defaultpgfile != "") {
                    defaultProgGroupFile = defaultpgfile;
                    LoadProgramGroup(defaultProgGroupFile);
                }
            } catch (ConfigurationErrorsException) {
                Console.WriteLine("Error reading settings");
            }
        }
        void WriteSettings(string key, string value) {
            try {
                Configuration configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                KeyValueConfigurationCollection settings = configFile.AppSettings.Settings;
                if (settings[key] == null) {
                    settings.Add(key, value);
                } else {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            } catch (ConfigurationErrorsException) {
                Console.WriteLine("Error writing settings");
            }
        }


        /* Program Groups (the lists of launch buttons)
         * */

        private void SaveProgramGroup(string path) {
            // save paths from buttons to a file
            using (StreamWriter outputFile = new StreamWriter(path)) {
                foreach (Control c in flowLayoutPanel1.Controls) {
                    outputFile.WriteLine(c.Tag);
                }
            }
        }

        private void LoadProgramGroup(string path) {
            // load saved paths and create buttons to launch each of them
            List<string> lines = new List<string>();

            if (File.Exists(path)) {
                defaultProgGroupFile = path; // set default pg file on loading
                flowLayoutPanel1.Controls.Clear();
                using (StreamReader inputFile = new StreamReader(path)) {
                    string line;
                    while ((line = inputFile.ReadLine()) != null) {
                        lines.Add(line);
                    }
                }
                foreach (string s in lines) {
                    AddButton(s);
                }
            }
        }

        private void OnClick_ProgramGroupName(object ob, System.EventArgs e) {
            // RecFileMenu Click Handler (load a prog group when its name is clicked in menu)
            string fn = "";
            FileInfo fi;

            fn = ((ToolStripMenuItem)ob).Text;
            fi = new FileInfo(fn);
            if (fi.Exists) {
                LoadProgramGroup(fn);
            }
        }
        private void OnClick_LaunchButton(object sender, EventArgs e) {
            if (!dragging) {
                LaunchFile(((Button)sender).Tag.ToString());
            }
        }

        private void DeleteBtn(Button btn) {
            // MouseMenu Delete: Confirm and remove selected button
            if (flowLayoutPanel1.Controls.Contains(btn)) {
                if (MessageBox.Show("Delete " + btn.Text, "Remove Button", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    flowLayoutPanel1.Controls.Remove(btn);
                }
            }
        }

        private void MoveLeft(Button btn) {
            // MouseMenu MoveLeft
            int index;

            index = flowLayoutPanel1.Controls.GetChildIndex(btn);
            if (index > 0) {
                flowLayoutPanel1.Controls.SetChildIndex(btn, index - 1);
            }
        }

        private void MoveRight(Button btn) {
            // MouseMenu MoveRight
            int index;

            index = flowLayoutPanel1.Controls.GetChildIndex(btn);
            if (index <= flowLayoutPanel1.Controls.Count) {
                flowLayoutPanel1.Controls.SetChildIndex(btn, index + 1);
            }
        }

        /* Recently-opened File menu (names of program groups)
         * */

        private void AddPathToRecentlyOpenedFileMenu(string fn) {
            // limit of 4 Files in menu
            if (fn != null) { // don't add a blank entry
                if (recFileMenu.DropDownItems.Count > 3) {
                    recFileMenu.DropDownItems.RemoveAt(recFileMenu.DropDownItems.Count - 1);
                }
                recFileMenu.DropDownItems.Add(new ToolStripMenuItem(fn, null, new EventHandler(OnClick_ProgramGroupName)));
            }
        }

        private void LoadRecentlyOpenedFileList(string path) {
            // Load recently opened file paths (previously saved into a file)
            // and add each path to the Recently-opened file menu
            List<string> lines = new List<string>();

            using (StreamReader inputFile = new StreamReader(path)) {
                string line;
                while ((line = inputFile.ReadLine()) != null) {
                    lines.Add(line);
                }
            }
            foreach (string s in lines) {
                AddPathToRecentlyOpenedFileMenu(s);
            }
        }

        private void SaveRecentlyOpenedFileList(string path) {
            using (StreamWriter outputFile = new StreamWriter(path)) {
                for (int i = 0; i < recFileMenu.DropDownItems.Count; i++) {
                    outputFile.WriteLine(recFileMenu.DropDownItems[i].Text);
                }
            }
        }
        private void popupMenu_ItemClicked(Object sender, ToolStripItemClickedEventArgs e) {
            // Handle Mouse Menu Item clicked
            string menuitem;
            Button btn;

            btn = (Button)popupMenu.SourceControl;
            menuitem = (e.ClickedItem).Text;

            if (e.ClickedItem == delBtnMenuItem) {
                DeleteBtn(btn);
            } else if (e.ClickedItem == moveLeftMenuItem) {
                MoveLeft(btn);
            } else if (e.ClickedItem == moveRightMenuItem) {
                MoveRight(btn);
            } else {
                MessageBox.Show("Unknown Menu Item: menuitem=" + menuitem);
            }
        }
        private void flowLayoutPanel1_DragDrop(object sender, DragEventArgs e) {
            // Drop items from File Explorer and create buttons to launch them
            Array filenames;

            if (e.Data != null) {
                filenames = (Array)e.Data.GetData(DataFormats.FileDrop);
                foreach (string s in filenames) {
                    AddButton(s);
                }
            }
        }

        private void flowLayoutPanel1_DragEnter(object sender, DragEventArgs e) {
            if (e.Data != null) {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                    e.Effect = DragDropEffects.Copy;
                } else {
                    e.Effect = DragDropEffects.None;
                }
            }
        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e) {
            flowLayoutPanel1.Controls.Clear();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
            openFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openFileDialog1.ShowDialog() == DialogResult.OK) {
                flowLayoutPanel1.Controls.Clear();
                LoadProgramGroup(openFileDialog1.FileName);
                AddPathToRecentlyOpenedFileMenu(openFileDialog1.FileName);
                defaultProgGroupFile = openFileDialog1.FileName;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveProgramGroup(saveFileDialog1.FileName);
            }
        }

        private void saveAstoolStripMenuItem_Click(object sender, EventArgs e) {
            saveFileDialog1.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
                SaveProgramGroup(saveFileDialog1.FileName);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e) {            
            if (File.Exists(recfile)) {
                LoadRecentlyOpenedFileList(recfile);
            }
            // Load Buttons of last saved config file                      
            ReadSettings();

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            // Save Recently opened File names           
            SaveRecentlyOpenedFileList(recfile);
            WriteSettings("x", this.Location.X.ToString());
            WriteSettings("y", this.Location.Y.ToString());
            WriteSettings("width", this.Width.ToString());
            WriteSettings("height", this.Height.ToString());
            WriteSettings("defaultpgfile", defaultProgGroupFile);
        }




    }

}